// config/database.js
module.exports = {

    'url' : 'mongodb+srv://demo:demo@cluster0.v11xd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', 
    'dbName': 'demo'
};
